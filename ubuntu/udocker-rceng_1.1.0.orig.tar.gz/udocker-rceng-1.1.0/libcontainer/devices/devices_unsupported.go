// +build !linux

package devices
