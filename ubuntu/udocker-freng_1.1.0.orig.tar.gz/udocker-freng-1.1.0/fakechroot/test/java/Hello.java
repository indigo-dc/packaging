class Hello {
   public static void main(String[] a) {
      System.out.println("Hello world!");
   }
}
