Manuals
=======

- `PRoot <doc/proot/manual.txt>`_

- `CARE <doc/care/manual.txt>`_


Build status
============

- .. image:: https://travis-ci.org/cedric-vincent/PRoot.png?branch=master
     :target: https://travis-ci.org/cedric-vincent/PRoot

- .. image:: https://coveralls.io/repos/cedric-vincent/PRoot/badge.png?branch=master
     :target: https://coveralls.io/r/cedric-vincent/PRoot?branch=master

- .. image:: https://scan.coverity.com/projects/602/badge.svg
     :target: https://scan.coverity.com/projects/602
