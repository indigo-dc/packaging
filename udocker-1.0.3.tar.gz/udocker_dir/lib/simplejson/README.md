simplejson
==========

simplejson is a simple, fast, extensible JSON encoder/decoder for Python 

This branch is for use in extreme situations where you cannot upgrade from Python 2.2, expect to get your hands dirty!

There is no release of this egg, you will rather want to check it out:

    git clone https://github.com/simplejson/simplejson.git --branch python2.2

Add install it in your old python:

    python2.2 setup.py install

Any features missing from the mainline version need to be coded in by hand. 
I hope this is useful, it should be better than starting from scratch!
