#!/bin/bash

# Compile in standalone for testing
#cc -DSTANDALONE -o pelf -g -O0 -I. -I.. patchelf.c -ldl

# full host OS pathname to patchelf executable compiled preferrably as static 
export FAKECHROOT_PATCH_PATCHELF=/home/jorge/mysoft/indigo/udocker/fake/bin/patchelf

# ELFLOADER can be the full host OS pathname to a loader or simply "true"
# if "true" the FAKECHROOT_BASE will be prepended to the executable loader
#export FAKECHROOT_PATCH_ELFLOADER=/lib64/ld-2.17.so
export FAKECHROOT_PATCH_ELFLOADER=/lib64/ld-linux-x86-64.so.2
#export FAKECHROOT_PATCH_ELFLOADER=true

# The standard FAKECHROOT_BASE as usual points to the top of the directory tree
export FAKECHROOT_BASE=/home/jorge/.udocker/containers/64d5abf3-d0b4-30fd-89a5-5df244dfa2ea/ROOT

# Test
./pelf

# Set or get manually the elf loader in this case CentOS 7
#/home/jorge/mysoft/indigo/udocker/fake/bin/patchelf --set-interpreter /lib64/ld-2.17.so /bin/true
#/home/jorge/mysoft/indigo/udocker/fake/bin/patchelf --get-interpreter /bin/true


