#include <stdio.h>

int main(int argc, char **argv)
{
	puts(argv[0]);
	return 0;
}
