package libcontainer

// Solaris - TODO

type Stats struct {
	Interfaces []*NetworkInterface
}
