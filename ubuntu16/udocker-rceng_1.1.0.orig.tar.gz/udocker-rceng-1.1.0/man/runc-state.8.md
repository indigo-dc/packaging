# NAME
   runc state - output the state of a container

# SYNOPSIS
   runc state <container-id>

Where "<container-id>" is your name for the instance of the container.

# DESCRIPTION
   The state command outputs current state information for the
instance of a container.
